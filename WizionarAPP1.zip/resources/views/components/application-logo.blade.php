<img src="{{ asset('images/logo.png') }}" alt="Logo" {{ $attributes->merge(['class' => 'vaša-klasa-za-stiliziranje']) }}>
