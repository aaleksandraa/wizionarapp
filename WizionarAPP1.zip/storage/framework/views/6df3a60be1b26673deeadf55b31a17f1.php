

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-4">
        <div class="mb-4">
            <label for="datePicker" class="block text-gray-700 text-sm font-bold mb-2">Odaberite datum:</label>
            <input type="text" id="datePicker" class="shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight">            
        </div> 
    </div>

    <?php if($appointments->isEmpty()): ?>
        <div class="alert alert-info">Trenutno nema dodanih usluga / pregleda za odabrani datum.</div>
    <?php else: ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 class="text-xl font-semibold mb-0"><?php echo e($user->name); ?> <?php echo e($user->surname); ?></h3> <!-- Uklonjena margina ispod H3 -->

            <?php
                $userAppointments = $appointments->where('user_id', $user->id);
            ?>

            <?php if($userAppointments->isEmpty()): ?>
                <div class="alert alert-info">Nema podataka za ovog korisnika.</div>
            <?php else: ?>
                <div class="bg-white shadow-md rounded my-6 hidden md:block">
                    <table class="text-left w-full border-collapse">
                        <thead class="bg-gray-300">
                            <tr>
                                <th class="py-2 px-4">Vrijeme</th>
                                <th class="py-2 px-4">Klijent</th>
                                <th class="py-2 px-4 hidden md:table-cell">Telefon</th>
                                <th class="py-2 px-4">Usluga</th>
                                <th class="py-2 px-4">Cijena</th>
                                <th class="py-2 px-4"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $userAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-100 <?php echo e($loop->even ? 'bg-gray-100' : ''); ?>">
                                    <td class="py-2 px-4"><?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $appointment->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $appointment->end_time)->format('H:i')); ?></td>
                                    <td class="py-2 px-4"><?php echo e($appointment->client->name); ?></td>
                                    <td class="py-2 px-4 hidden md:table-cell"><?php echo e($appointment->client->phone); ?></td>
                                    <td class="py-2 px-4"><?php echo e($appointment->service->name); ?></td>
                                    <td class="py-2 px-4"><?php echo e($appointment->service->price); ?> KM</td>
                                    <td class="py-2 px-4">
                                        <a href="<?php echo e(route('appointments.edit', $appointment->id)); ?>" class="text-pink-600 hover:text-pink-700"><i class="fas fa-edit"></i></a>
                                        <form action="<?php echo e(route('appointments.destroy', $appointment->id)); ?>" method="POST" class="inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-500 hover:text-red-800 ml-2"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <?php
                    $totalPriceForUser = $userAppointments->sum(function ($appointment) {
                        return $appointment->service->price;
                    });
                ?>

                <div class="flex justify-end mb-20 hidden md:block"> <!-- Povećan razmak posle tabele -->
                    <div class="text-xl font-semibold">Ukupan promet: <span class="ml-2"><?php echo e($totalPriceForUser); ?> KM</span></div>
                </div>
                
                

            <?php endif; ?>
        

        <?php if(!$userAppointments->isEmpty()): ?>
        <div class="bg-white shadow-md rounded my-6 block md:hidden">
            <?php $__currentLoopData = $userAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-4 mb-4 border-b">
                <div><strong>Vrijeme:</strong> <?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $appointment->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $appointment->end_time)->format('H:i')); ?></div>
                <div><strong>Klijent:</strong> <?php echo e($appointment->client->name); ?></div>
                <div><strong>Telefon:</strong> <?php echo e($appointment->client->phone); ?></div>
                <div><strong>Usluga:</strong> <?php echo e($appointment->service->name); ?></div>
                <div><strong>Cijena:</strong> <?php echo e($appointment->service->price); ?> KM</div>
                <div class="flex justify-end mt-2">
                    <a href="<?php echo e(route('appointments.edit', $appointment->id)); ?>" class="text-pink-600 hover:text-pink-700"><i class="fas fa-edit"></i></a>
                    <form action="<?php echo e(route('appointments.destroy', $appointment->id)); ?>" method="POST" class="inline-block ml-2">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-500 hover:text-red-800"><i class="fa fa-trash"></i></button>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="flex justify-end mb-20 md:hidden"> <!-- Povećan razmak posle tabele -->
            <div class="text-xl font-semibold">Ukupan promet: <span class="ml-2"><?php echo e($totalPriceForUser); ?> KM</span></div>
        </div>
        <?php endif; ?>

        <div class="mb-8"></div> <!-- Ovo je nova linija za veći razmak -->

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>








<script>
    // Funkcija za formatiranje datuma
    function formatDate(date) {
        var d = new Date(date),
            day = '' + d.getDate(),
            month = '' + (d.getMonth() + 1),
            year = d.getFullYear();

        if (day.length < 2) 
            day = '0' + day;
        if (month.length < 2) 
            month = '0' + month;

        return [day, month, year].join('.');
    }

    // Provera da li postoji datum u URL-u
    function getDateFromUrl() {
        const pathParts = window.location.pathname.split('/');
        const datePart = pathParts[pathParts.length - 1];
        if (datePart.match(/\d{4}-\d{2}-\d{2}/)) {
            return new Date(datePart);
        }
        return new Date(); // Vraća današnji datum ako datum nije u URL-u
    }

    const selectedDate = getDateFromUrl();

    // Postavljanje placeholder-a na osnovu izabranog datuma ili današnjeg datuma
    document.getElementById('datePicker').placeholder = formatDate(selectedDate);

    flatpickr("#datePicker", {
        altInput: true,
        altFormat: "d.m.Y",
        dateFormat: "Y-m-d",
        defaultDate: selectedDate,
        locale: "sr",
        onChange: function(selectedDates, dateStr, instance) {
            window.location.href = '<?php echo e(route("appointments.index")); ?>?date=' + dateStr;
        }
    });

    function getDateFromUrl() {
    // Uzimanje URL parametara
    const queryParams = new URLSearchParams(window.location.search);
    // Provjera da li postoji 'date' parametar
    const dateParam = queryParams.get('date');
    if (dateParam && dateParam.match(/\d{4}-\d{2}-\d{2}/)) {
        return new Date(dateParam);
    }
    return new Date(); // Vraća današnji datum ako datum nije pronađen u parametrima URL-a
}

</script>
<?php $__env->stopSection(); ?>





   
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aleks\Desktop\wizionarCRM\WizionarAPP\resources\views/appointments/admin_index.blade.php ENDPATH**/ ?>