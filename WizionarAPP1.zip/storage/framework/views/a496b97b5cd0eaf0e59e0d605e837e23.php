

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="mb-4">
        <input type="text" id="searchBox" class="shadow border rounded w-full py-2 px-3 text-gray-700" placeholder="Pretraži klijente...">
    </div>

    <div id="clientList">
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white p-4 mb-4 shadow rounded">
                <div><?php echo e($client->name); ?></div>
                <div><?php echo e($client->email); ?></div>
                <div><?php echo e($client->phone); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<script>
    document.getElementById('searchBox').addEventListener('keyup', function() {
        var search = this.value;
        fetch("<?php echo e(route('api.clients.index')); ?>?search=" + search)
            .then(response => response.json())
            .then(data => {
                var clientListHtml = '';
                data.forEach(client => {
                    clientListHtml += `
                        <div class="bg-white p-4 mb-4 shadow rounded">
                            <div>${client.name}</div>
                            <div>${client.email}</div>
                            <div>${client.phone}</div>
                        </div>
                    `;
                });
                document.getElementById('clientList').innerHTML = clientListHtml;
            });
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aleks\Desktop\wizionarCRM\WizionarAPP\resources\views/clients/index.blade.php ENDPATH**/ ?>