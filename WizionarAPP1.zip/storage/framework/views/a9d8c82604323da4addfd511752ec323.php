<?php $__env->startSection('content'); ?>
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <!-- Trenutni Dnevni Promet -->        
            <div class="bg-white dark:bg-gray-200 overflow-hidden shadow-sm sm:rounded-lg p-4 cursor-pointer" onclick="redirectToAppointments()">

            <h3 class="font-semibold text-lg dark:bg-gray-300 text-center">Trenutni Dnevni Promet</h3>
            <br/>
            <div class="text-center">
                <p class="text-3xl">
                    <?php echo e(number_format($currentDailyRevenue, 2)); ?> KM
                </p>
                <p class="text-sm">
                    Trenutni broj tretmana danas: <?php echo e($dnevniBrojServisa); ?>

                </p>
                <p class="text-sm">
                    <?php $__currentLoopData = $usersRevenueToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userRevenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($userRevenue->user->name); ?>: <?php echo e($userRevenue->revenue); ?> KM</p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            </div>
        </div>  

        
        
        
         <!-- Sedmični Promet -->
         <?php if(isset($weeklyRevenue)): ?>
         <div class="bg-white dark:bg-gray-200 overflow-hidden shadow-sm sm:rounded-lg p-4">
             <h3 class="font-semibold text-lg dark:bg-gray-300 text-center">Sedmični Promet</h3>
             <br/>
             <div class="text-center">
                 <p class="text-3xl">
                     <?php echo e(number_format($weeklyRevenue['thisWeekRevenue'], 2)); ?> KM
                     <sup class="<?php echo e($weeklyRevenue['percentageChange'] >= 0 ? 'text-green-500' : 'text-red-500'); ?>" style="font-size: 15px;">
                         <?php echo e(number_format($weeklyRevenue['percentageChange'], 2)); ?>%
                     </sup>
                 </p>
                 <p class="text-sm">Prošla sedmica: <?php echo e(number_format($weeklyRevenue['lastWeekRevenue'], 2)); ?> KM</p>
             </div>
         </div>
         
     <?php endif; ?>

        <!-- Mjesečni Promet -->        
        <div class="text-center bg-white dark:bg-gray-200 overflow-hidden shadow-sm sm:rounded-lg p-4">
            <h3 class="font-semibold text-lg dark:bg-gray-300 text-center">Mjesečni Promet</h3> 
            <br/>
            <p class="text-center text-3xl">
                <?php echo e(number_format($monthlyTotalRevenue, 2)); ?> KM
            </p>
            
            <p class="text-sm">
                <?php if($monthlyUsersRevenue->isNotEmpty()): ?>
                    <?php $__currentLoopData = $monthlyUsersRevenue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userRevenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($userRevenue->user->name); ?>: <?php echo e($userRevenue->total_revenue); ?> KM</p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>Nema podataka o prometu korisnika ovog mjeseca.</p>
                <?php endif; ?>
            </p>
        </div>

        

</div>
</div>

<script>
    function redirectToAppointments() {
        window.location.href = '<?php echo e(url("/appointments")); ?>';
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aleks\Desktop\wizionarCRM\WizionarAPP\resources\views/dashboard.blade.php ENDPATH**/ ?>