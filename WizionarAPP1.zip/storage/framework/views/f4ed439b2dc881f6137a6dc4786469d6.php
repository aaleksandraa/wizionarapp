

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="flex flex-col items-center justify-center">
        <div class="w-full max-w-4xl">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-2xl font-semibold">Usluge</h2>
                <a href="<?php echo e(route('usluge.create')); ?>" class="bg-pink-500 hover:bg-pink-700 text-white font-bold py-2 px-4 rounded">Dodaj Novu Uslugu</a>
            </div>

            <?php if($services->isEmpty()): ?>
                <div class="alert alert-info">Trenutno nema dostupnih usluga.</div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white shadow rounded p-4">
                            <h3 class="text-lg font-semibold"><?php echo e($service->name); ?></h3>
                            <p class="text-gray-700"><?php echo e($service->price); ?> KM</p>
                            <div class="flex mt-4">
                                <a href="<?php echo e(route('usluge.edit', $service->id)); ?>" class="text-gray-600 hover:text-pink-700 mr-2">
                                    Izmijeni
                                </a>
                                <form action="<?php echo e(route('usluge.destroy', $service->id)); ?>" method="POST" class="ml-4">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-800" onclick="return confirm('Da li ste sigurni da želite obrisati ovu uslugu?')">
                                        Obriši
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aleks\Desktop\wizionarCRM\WizionarAPP\resources\views/usluge/index.blade.php ENDPATH**/ ?>